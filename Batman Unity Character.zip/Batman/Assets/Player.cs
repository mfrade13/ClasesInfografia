﻿using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

public class Player : MonoBehaviour
{
    bool jump = false;
    public Animator animator;
    // Update is called once per frame
    void Update()
    {
        transform.Translate(Input.GetAxis("Horizontal")* 15f * Time.deltaTime, 0f, 0f);

        Vector3 characterScale = transform.localScale;
        if (Input.GetAxis("Horizontal")<0) {
            characterScale.x = -1;
        }

        if (Input.GetAxis("Horizontal") > 0)
        {
            characterScale.x = 1;
        }
        if (Input.GetButtonDown("Jump") && jump==false)
        {
            gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(0f, 30f), ForceMode2D.Impulse);
            jump = true;
            Task.Delay(850).ContinueWith(t => jump=false);
            animator.SetFloat("speedy", 1);
        }
        if (jump == false) {
            animator.SetFloat("speedy", 0);
        }

        transform.localScale = characterScale;
    }



}
